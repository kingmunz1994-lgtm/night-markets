# ⊘ Night Markets

**Zero-Knowledge Global Marketplace — Built on Midnight Network**

> Buy anything. From anywhere. Leave no trace. 🌑

[![Built on Midnight](https://img.shields.io/badge/Built%20on-Midnight%20Network-7C3AED)](https://midnight.network)
[![Compact](https://img.shields.io/badge/Compact-0.28.0-9d5cf6)](https://docs.midnight.network)
[![Status](https://img.shields.io/badge/Status-Preprod%20Deploying-f5c518)](https://github.com/kingmunz1994-lgtm/night-markets)
[![License](https://img.shields.io/badge/License-MIT-00d68f)](LICENSE)

---

## What is Night Markets?

Night Markets is the first privacy-first global marketplace built natively on the Midnight Network. It enables any buyer to purchase goods from any seller globally — with zero data exposure, zero financial surveillance, and zero intermediary control.

Built on Compact — Midnight's zero-knowledge smart contract language — Night Markets uses ZK proofs to guarantee that payment is valid without revealing the buyer's identity, balance, or purchase history.

**The seller confirms delivery. The escrow releases funds. No third party sees anything they shouldn't.**

---

## ⊘ Try the Demo

No wallet required. Download [`night-markets-v14.html`](night-markets-v14.html), open in Chrome, click **"Try Demo"** — explore the full ZK marketplace experience including checkout, Pay-in-4 BNPL, governance voting, and loyalty tiers.

---

## 🔑 Key Features

| Feature | Description |
|---|---|
| **ZK Escrow** | 5-state escrow machine enforced by ZK proofs. Seller and buyer identities never exposed. |
| **Pay-in-4 BNPL** | On-chain instalment enforcement. No lender. No interest. No credit check. No data. |
| **Private Governance** | ZK-anonymous weighted voting with double-vote protection via castVote circuit. |
| **ZK Certificates** | Blockchain certificates of authenticity. Prove provenance without exposing supply chain. |
| **Sybil-Resistant Reputation** | NIGHT-staked seller reputation via ZK commitments. Portable. Private. Fraud-resistant. |
| **Local AI** | On-device product recommendations. No profile. No targeting. No data leaves the browser. |

---

## 📦 Contract — NightMarketsEscrow.compact

**Version 2 — Security audited against adavault Midnight Compact Agent Skill**

```
circuits:        6
complexity:      k=13
compiler:        Compact 0.28.0
network:         Midnight Preprod → Mainnet (March 2026)
status:          Compiled clean ✅ — Deploying ⏳
```

### Circuit summary

| Circuit | Auth | State transition |
|---|---|---|
| `createListing` | Seller ZK commit | NONE → OPEN |
| `fundEscrow` | Buyer ZK commit | OPEN → FUNDED |
| `releaseEscrow` | Buyer `callerCommitment` | FUNDED → RELEASED |
| `disputeEscrow` | Buyer `callerCommitment` | FUNDED → DISPUTED |
| `refundEscrow` | Seller `callerCommitment` | FUNDED → REFUNDED |
| `castVote` | Double-vote guard + weight cap | Governance |

### Security fixes in v2
- `releaseEscrow` / `disputeEscrow` — buyer authenticates via `callerCommitment("buyer")`
- `refundEscrow` — seller authenticates via `callerCommitment("seller")`
- `castVote` — double-vote guard: `assert(has_voted.member(voterComPublic) == false)`
- `round` changed from `Cell<Uint<32>>` to `Counter` (contention resistance)
- Vote weight capped at 1,000,000,000,000 microNIGHT

---

## 🚀 Deploy

```bash
# In WSL Ubuntu
cd /mnt/c/Users/lukey/Downloads/night-markets-project

# Compile contract
/home/nightmarkets/.local/bin/compact compile \
  contracts/NightMarketsEscrow.compact \
  contracts/managed/night-markets-escrow

# Deploy to Preprod
npm run deploy
```

**Prerequisites:**
- Node v24+ 
- Lace Midnight extension (Preprod, Remote proof server)
- Funded wallet with tDUST
- `.env` with `WALLET_SEED=<hex>`

**Preprod endpoints:**
```
Indexer:     https://indexer.preprod.midnight.network/api/v3/graphql
Node:        https://rpc.preprod.midnight.network
Proof server: https://lace-proof-pub.preprod.midnight.network
```

---

## 🛍️ Night Markets Store

The first and only Midnight Network community merch store — launching on Shopify.

- **⊘ Night Markets collection** — void aesthetic, "Leave no trace"
- **🌑 Midnight Network collection** — community merch, first in ecosystem
- Accepts ADA, ETH, USDC, card — NIGHT token checkout when contract deploys
- **10% of Midnight collection profits** sent to Midnight ecosystem fund — publicly tracked on-chain
- **Man of the Match** — monthly community vote, winner's design on limited edition merch drop

---

## 📄 Documents

| Document | Description |
|---|---|
| [Whitepaper v1.0](docs/night-markets-whitepaper.docx) | Full project vision, technical architecture, market opportunity, risk register |
| [Design Documents v1.1](docs/night-markets-design-docs-v1.1.docx) | Sybil resistance, account recovery, dispute escrow with merchant liquidity |
| [Parameters & Legal Memo](docs/night-markets-params-legal.docx) | Attack-cost modelling, circuit specs, legal risk memo template for counsel |

---

## 🤝 Ecosystem Partners

Night Markets is actively seeking ecosystem-native partners for:

| Need | Who we're talking to |
|---|---|
| KYC/AML compliance layer | Fairway (Midnight ecosystem) |
| Stablecoin settlement | W3i Software / ShieldUSD (Midnight ecosystem) |
| Sanctions screening | Provenance (Midnight ecosystem) |
| Dev studio support | Brick Towers (Midnight ecosystem) |
| Fiat on/off-ramp | In conversation |
| Legal counsel | Seeking crypto/fintech specialist |

**Building on Midnight and want to integrate?** Open an issue or DM in Midnight Discord.

---

## 🌐 Community

- **Midnight Discord** — `#showcase` and `#dev-chat`
- **Man of the Match** — vote monthly for the best Midnight builder
- **Builder of the Month** — winner gets limited edition Night Markets merch
- **Partner programme** — 20% rev share for ecosystem project merch

---

## 📊 Project Status

```
✅ Smart contract v2 — compiled, security audited
✅ Frontend v14 — 5,431 lines, demo mode, Lace integration
✅ Whitepaper + design docs — complete document set
✅ Merch store — designed, launching on Shopify
✅ Community — Discord traction, Man of the Match launched
⏳ Preprod deployment — waiting on faucet
⏳ Shopify store — setup in progress
🌑 Mainnet — March 2026
```

---

## 💰 Funding

Night Markets is seeking **$50,000–$150,000** in ecosystem grant funding to cover:
- Mainnet deployment and legal review
- Fiat settlement partner integration
- First 1,000 real transactions pilot
- Senior payments/compliance advisor

**Interested in supporting Night Markets?** Open an issue, DM in Discord, or email via GitHub.

---

## 🗺️ Roadmap

| Phase | Timeline | Milestone |
|---|---|---|
| **Phase 1** | Now | Contract deployed, merch store live, community growing |
| **Phase 2** | Month 1–3 | NIGHT token checkout, creator programme, ecosystem partners |
| **Phase 3** | Month 3–6 | Mainnet, real goods, ZK certificates, live commerce |
| **Phase 4** | Month 6–12 | AI agent marketplace, global scale, $1M GMV target |

---

## 🏗️ Tech Stack

```
Blockchain:     Midnight Network
Language:       Compact 0.28.0 (ZK circuits)
SDK:            @midnight-ntwrk/midnight-js 3.0.0
Wallet:         Lace Midnight (Preprod)
Proof server:   Remote (Lace proof pub)
Frontend:       Vanilla JS PWA (single file, no build step)
Store:          Shopify + Printful + NOWPayments
```

---

## 📁 Repository Structure

```
night-markets/
├── contracts/
│   ├── NightMarketsEscrow.compact      # Main ZK escrow contract v2
│   └── managed/night-markets-escrow/   # Compiled circuit outputs
├── scripts/
│   └── deploy.ts                       # Deployment script
├── docs/
│   ├── night-markets-whitepaper.docx
│   ├── night-markets-design-docs-v1.1.docx
│   └── night-markets-params-legal.docx
├── night-markets-v14.html              # Full PWA frontend + demo mode
└── .env.example                        # Environment template
```

---

## ⚖️ License

MIT — see [LICENSE](LICENSE)

---

*Night Markets — Buy anything. From anywhere. Leave no trace. ⊘*

*Built on Midnight Network · ZK · NIGHT · DUST · Privacy by architecture*
